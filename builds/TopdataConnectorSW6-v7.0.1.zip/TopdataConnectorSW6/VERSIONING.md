# Versioning Scheme
- for each major shopware6 version there is a branch with a major plugin version number:
    - Shopware 6.4: branch=main-sw64 major-version=1
    - Shopware 6.5: branch=main-sw65 major-version=2
    - Shopware 6.6: branch=main-sw66 major-version=3
  
