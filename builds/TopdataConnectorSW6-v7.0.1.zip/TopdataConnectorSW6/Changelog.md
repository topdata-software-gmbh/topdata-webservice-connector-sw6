# Changelog

[7.0.0] - 06/2024
- prettier output
- deprecation warnings fixed
- report generation when importing data

- [7.0.2] - 2024-11-04
- removed some classes and the csv import command
- added migration for inserting default credentials if no credentials are present

