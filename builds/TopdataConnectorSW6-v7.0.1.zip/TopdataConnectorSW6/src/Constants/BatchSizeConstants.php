<?php

namespace Topdata\TopdataConnectorSW6\Constants;

class BatchSizeConstants
{
    const ENABLE_DEVICES      = 100;
    const ENABLE_BRANDS       = 200;
    const ENABLE_SERIES       = 200;
    const ENABLE_DEVICE_TYPES = 200;
}
