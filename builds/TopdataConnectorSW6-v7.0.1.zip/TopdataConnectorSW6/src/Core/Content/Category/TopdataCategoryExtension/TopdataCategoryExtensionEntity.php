<?php

declare(strict_types=1);

namespace Topdata\TopdataConnectorSW6\Core\Content\Category\TopdataCategoryExtension;

use Shopware\Core\Framework\DataAbstractionLayer\Entity;

class TopdataCategoryExtensionEntity extends Entity
{
}
