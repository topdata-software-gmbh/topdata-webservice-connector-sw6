<?php

declare(strict_types=1);

namespace Topdata\TopdataConnectorSW6\Core\Content\Product\Agregate\ProductCrossSelling;

use Shopware\Core\Framework\DataAbstractionLayer\Entity;

class TopdataProductCrossSellingExtensionEntity extends Entity
{
}
